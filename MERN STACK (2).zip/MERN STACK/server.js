const express =require('express');
const app = express();

//middeleware
app.get('/',(req,res)=>{
    res.send("Welcome to Express Js");
})

app.listen(4000,()=>{
    console.log("Server started at 4000");
})